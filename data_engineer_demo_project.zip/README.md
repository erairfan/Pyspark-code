# PySpark Sales ETL

Demo Data Engineering project.

## Features
- SparkSession
- DataFrame creation
- GroupBy aggregation
- Simple ETL flow

## Run
spark-submit main.py

Note:
This is a demo project created to showcase PySpark skills.
